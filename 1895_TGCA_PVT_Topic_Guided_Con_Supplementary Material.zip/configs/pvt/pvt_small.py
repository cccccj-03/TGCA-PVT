cfg = dict(
    model='pvt_small',
    drop_path=0.1,
    clip_grad=None
)