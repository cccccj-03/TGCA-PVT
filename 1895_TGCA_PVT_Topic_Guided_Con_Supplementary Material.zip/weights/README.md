Please download the ImageNet pre-trained model weights for PVTv1-small from [PVT](https://github.com/whai362/PVT/tree/v2/classification) and place it in this folder.


